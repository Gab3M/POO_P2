﻿namespace Questao02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rb_onibus = new System.Windows.Forms.RadioButton();
            this.rb_caminhao = new System.Windows.Forms.RadioButton();
            this.lb_placa = new System.Windows.Forms.Label();
            this.lb_ano = new System.Windows.Forms.Label();
            this.tb_placa = new System.Windows.Forms.MaskedTextBox();
            this.tb_ano = new System.Windows.Forms.TextBox();
            this.pn_onibus = new System.Windows.Forms.Panel();
            this.lb_assentos = new System.Windows.Forms.Label();
            this.tb_assentos = new System.Windows.Forms.TextBox();
            this.pn_caminhao = new System.Windows.Forms.Panel();
            this.lb_eixos = new System.Windows.Forms.Label();
            this.tb_eixos = new System.Windows.Forms.TextBox();
            this.bt_cadastrar = new System.Windows.Forms.Button();
            this.bt_limpar = new System.Windows.Forms.Button();
            this.pb_imagens = new System.Windows.Forms.PictureBox();
            this.pn_onibus.SuspendLayout();
            this.pn_caminhao.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_imagens)).BeginInit();
            this.SuspendLayout();
            // 
            // rb_onibus
            // 
            this.rb_onibus.AutoSize = true;
            this.rb_onibus.Location = new System.Drawing.Point(27, 31);
            this.rb_onibus.Name = "rb_onibus";
            this.rb_onibus.Size = new System.Drawing.Size(58, 17);
            this.rb_onibus.TabIndex = 0;
            this.rb_onibus.TabStop = true;
            this.rb_onibus.Text = "Ônibus";
            this.rb_onibus.UseVisualStyleBackColor = true;
            this.rb_onibus.CheckedChanged += new System.EventHandler(this.rb_onibus_CheckedChanged);
            // 
            // rb_caminhao
            // 
            this.rb_caminhao.AutoSize = true;
            this.rb_caminhao.Location = new System.Drawing.Point(215, 31);
            this.rb_caminhao.Name = "rb_caminhao";
            this.rb_caminhao.Size = new System.Drawing.Size(72, 17);
            this.rb_caminhao.TabIndex = 1;
            this.rb_caminhao.TabStop = true;
            this.rb_caminhao.Text = "Caminhão";
            this.rb_caminhao.UseVisualStyleBackColor = true;
            this.rb_caminhao.CheckedChanged += new System.EventHandler(this.rb_caminhao_CheckedChanged);
            // 
            // lb_placa
            // 
            this.lb_placa.AutoSize = true;
            this.lb_placa.Location = new System.Drawing.Point(66, 83);
            this.lb_placa.Name = "lb_placa";
            this.lb_placa.Size = new System.Drawing.Size(34, 13);
            this.lb_placa.TabIndex = 3;
            this.lb_placa.Text = "Placa";
            this.lb_placa.Click += new System.EventHandler(this.lb_placa_Click);
            // 
            // lb_ano
            // 
            this.lb_ano.AutoSize = true;
            this.lb_ano.Location = new System.Drawing.Point(74, 116);
            this.lb_ano.Name = "lb_ano";
            this.lb_ano.Size = new System.Drawing.Size(26, 13);
            this.lb_ano.TabIndex = 4;
            this.lb_ano.Text = "Ano";
            // 
            // tb_placa
            // 
            this.tb_placa.Location = new System.Drawing.Point(107, 80);
            this.tb_placa.Mask = "AAA-0000";
            this.tb_placa.Name = "tb_placa";
            this.tb_placa.Size = new System.Drawing.Size(180, 20);
            this.tb_placa.TabIndex = 5;
            // 
            // tb_ano
            // 
            this.tb_ano.Location = new System.Drawing.Point(107, 113);
            this.tb_ano.Name = "tb_ano";
            this.tb_ano.Size = new System.Drawing.Size(180, 20);
            this.tb_ano.TabIndex = 6;
            // 
            // pn_onibus
            // 
            this.pn_onibus.Controls.Add(this.tb_assentos);
            this.pn_onibus.Controls.Add(this.lb_assentos);
            this.pn_onibus.Location = new System.Drawing.Point(27, 139);
            this.pn_onibus.Name = "pn_onibus";
            this.pn_onibus.Size = new System.Drawing.Size(270, 53);
            this.pn_onibus.TabIndex = 7;
            // 
            // lb_assentos
            // 
            this.lb_assentos.AutoSize = true;
            this.lb_assentos.Location = new System.Drawing.Point(3, 20);
            this.lb_assentos.Name = "lb_assentos";
            this.lb_assentos.Size = new System.Drawing.Size(70, 13);
            this.lb_assentos.TabIndex = 0;
            this.lb_assentos.Text = "Qtd Assentos";
            // 
            // tb_assentos
            // 
            this.tb_assentos.Location = new System.Drawing.Point(80, 17);
            this.tb_assentos.Name = "tb_assentos";
            this.tb_assentos.Size = new System.Drawing.Size(180, 20);
            this.tb_assentos.TabIndex = 1;
            // 
            // pn_caminhao
            // 
            this.pn_caminhao.Controls.Add(this.tb_eixos);
            this.pn_caminhao.Controls.Add(this.lb_eixos);
            this.pn_caminhao.Location = new System.Drawing.Point(27, 139);
            this.pn_caminhao.Name = "pn_caminhao";
            this.pn_caminhao.Size = new System.Drawing.Size(270, 60);
            this.pn_caminhao.TabIndex = 8;
            // 
            // lb_eixos
            // 
            this.lb_eixos.AutoSize = true;
            this.lb_eixos.Location = new System.Drawing.Point(21, 21);
            this.lb_eixos.Name = "lb_eixos";
            this.lb_eixos.Size = new System.Drawing.Size(52, 13);
            this.lb_eixos.TabIndex = 0;
            this.lb_eixos.Text = "Qtd Eixos";
            // 
            // tb_eixos
            // 
            this.tb_eixos.Location = new System.Drawing.Point(80, 18);
            this.tb_eixos.Name = "tb_eixos";
            this.tb_eixos.Size = new System.Drawing.Size(180, 20);
            this.tb_eixos.TabIndex = 1;
            // 
            // bt_cadastrar
            // 
            this.bt_cadastrar.Location = new System.Drawing.Point(27, 218);
            this.bt_cadastrar.Name = "bt_cadastrar";
            this.bt_cadastrar.Size = new System.Drawing.Size(114, 23);
            this.bt_cadastrar.TabIndex = 10;
            this.bt_cadastrar.Text = "Cadastrar";
            this.bt_cadastrar.UseVisualStyleBackColor = true;
            this.bt_cadastrar.Click += new System.EventHandler(this.bt_cadastrar_Click);
            // 
            // bt_limpar
            // 
            this.bt_limpar.Location = new System.Drawing.Point(179, 218);
            this.bt_limpar.Name = "bt_limpar";
            this.bt_limpar.Size = new System.Drawing.Size(118, 23);
            this.bt_limpar.TabIndex = 11;
            this.bt_limpar.Text = "Limpar";
            this.bt_limpar.UseVisualStyleBackColor = true;
            this.bt_limpar.Click += new System.EventHandler(this.bt_limpar_Click);
            // 
            // pb_imagens
            // 
            this.pb_imagens.Image = global::Questao02.Properties.Resources.branco;
            this.pb_imagens.Location = new System.Drawing.Point(318, 61);
            this.pb_imagens.Name = "pb_imagens";
            this.pb_imagens.Size = new System.Drawing.Size(180, 139);
            this.pb_imagens.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_imagens.TabIndex = 9;
            this.pb_imagens.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 376);
            this.Controls.Add(this.bt_limpar);
            this.Controls.Add(this.bt_cadastrar);
            this.Controls.Add(this.pn_caminhao);
            this.Controls.Add(this.pb_imagens);
            this.Controls.Add(this.pn_onibus);
            this.Controls.Add(this.tb_ano);
            this.Controls.Add(this.tb_placa);
            this.Controls.Add(this.lb_ano);
            this.Controls.Add(this.lb_placa);
            this.Controls.Add(this.rb_caminhao);
            this.Controls.Add(this.rb_onibus);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pn_onibus.ResumeLayout(false);
            this.pn_onibus.PerformLayout();
            this.pn_caminhao.ResumeLayout(false);
            this.pn_caminhao.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_imagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rb_onibus;
        private System.Windows.Forms.RadioButton rb_caminhao;
        private System.Windows.Forms.Label lb_placa;
        private System.Windows.Forms.Label lb_ano;
        private System.Windows.Forms.MaskedTextBox tb_placa;
        private System.Windows.Forms.TextBox tb_ano;
        private System.Windows.Forms.Panel pn_onibus;
        private System.Windows.Forms.TextBox tb_assentos;
        private System.Windows.Forms.Label lb_assentos;
        private System.Windows.Forms.Panel pn_caminhao;
        private System.Windows.Forms.TextBox tb_eixos;
        private System.Windows.Forms.Label lb_eixos;
        private System.Windows.Forms.PictureBox pb_imagens;
        private System.Windows.Forms.Button bt_cadastrar;
        private System.Windows.Forms.Button bt_limpar;
    }
}

