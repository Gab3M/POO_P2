﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questao02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pb_imagens.Image = Properties.Resources.branco;
            ocualtaPainel();
        }

        void ocualtaPainel()
        {
            pn_caminhao.Visible = false;
            pn_onibus.Visible = false;
        }

        private void lb_placa_Click(object sender, EventArgs e)
        {

        }

        private void rb_onibus_CheckedChanged(object sender, EventArgs e)
        {
            pb_imagens.Image = Properties.Resources.Onibus;
            ocualtaPainel();
            pn_onibus.Visible = true;
        }

        private void rb_caminhao_CheckedChanged(object sender, EventArgs e)
        {
            pb_imagens.Image = Properties.Resources.caminhao;
            ocualtaPainel();
            pn_caminhao.Visible = true;
        }

        private void bt_cadastrar_Click(object sender, EventArgs e)
        {
            if(rb_caminhao.Checked)
            {
                Caminhao caminhao = new Caminhao(tb_placa.Text, Convert.ToInt32(tb_ano.Text), Convert.ToDouble(tb_eixos.Text));
                MessageBox.Show("Valor do aluguel: " + caminhao.Alugar());
            }
            else if(rb_onibus.Checked)
            {
                Onibus onibus = new Onibus(tb_placa.Text, Convert.ToInt32(tb_ano.Text), Convert.ToInt32(tb_assentos.Text));
                MessageBox.Show("Valor do aluguel: " + onibus.Alugar());
            }
        }

        private void bt_limpar_Click(object sender, EventArgs e)
        {
            tb_placa.Text = string.Empty;
            tb_ano.Text = string.Empty;
            tb_eixos.Text = string.Empty;
            tb_assentos.Text = string.Empty;
        }
    }
}
