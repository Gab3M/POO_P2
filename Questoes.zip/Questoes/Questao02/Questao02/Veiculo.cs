﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao02
{
    abstract public class Veiculo
    {
        private string placa;
        private int ano;

        public Veiculo()
        {
            placa = string.Empty;
            ano = 0;
        }

        public Veiculo(string placa, int ano)
        {
            this.placa = placa;
            this.ano = ano;
        }

        public string Placa { get => placa; set => placa = value; }
        public int Ano { get => ano; set => ano = value; }

        public abstract double Alugar();
    }
}
