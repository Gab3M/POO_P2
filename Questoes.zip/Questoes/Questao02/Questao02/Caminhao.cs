﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao02
{
    internal class Caminhao : Veiculo
    {
        private double eixos;

        public Caminhao(string _placa, int _ano, double _eixos) : base(_placa, _ano)
        {
            eixos = _eixos;
        }
        public double Eixos { get => eixos; set => eixos = value; }

        public override double Alugar()
        {
            return ((300 * eixos) - ((2024 - Ano) * 50));
        }
    }
}
