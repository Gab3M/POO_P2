﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao01
{
    internal class NoPilha
    {
        private string peca;
        private NoPilha proximo;

        public NoPilha(string peca)
        {
            this.peca = peca;
            this.proximo = null;
        }

        public string Peca { get => peca; set => peca = value; }
        internal NoPilha Proximo { get => proximo; set => proximo = value; }
    }
}
