﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pilha p1 = new Pilha();
            bool aux = true;
            while (aux)
            {
                aux = Menu(p1);
            }
        }

        private static bool Menu(Pilha p1)
        {
            Console.WriteLine("Selecione uma opcao:");
            Console.WriteLine("1 - Inserir peca");
            Console.WriteLine("2 - Remover peca");
            Console.WriteLine("3 - Remover peca selecionada");
            Console.WriteLine("4 - Verificar valor do topo");
            Console.WriteLine("5 - Imprimir pilha");
            Console.WriteLine("6 - Sair");
            int opcao = int.Parse(Console.ReadLine());
            switch (opcao)
            {
                case 1:
                    Console.WriteLine("Digite a peca:");
                    string temp = Console.ReadLine();
                    p1.Push(temp);
                    return true;

                case 2:
                    Console.WriteLine("Peca removida: " + p1.Pop());
                    return true;

                case 3:
                    Console.WriteLine("Digite a peca:");
                    string peca = Console.ReadLine();
                    p1.PopValue(peca);
                    return true;

                case 4:
                    Console.WriteLine("Peca do topo: " + p1.Peek());
                    return true;

                case 5:
                    Console.WriteLine("Pilha:");
                    p1.Print();
                    return true;

                default:
                    return false;
            }
        }
    }
}
