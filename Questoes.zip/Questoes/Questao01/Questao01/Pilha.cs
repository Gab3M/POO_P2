﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao01
{
    internal class Pilha
    {
        private NoPilha topo;

        public Pilha()
        {
            this.topo = null;
        }

        public void Push(string peca)
        {
            NoPilha novo = new NoPilha(peca);
            novo.Proximo = topo;
            topo = novo;
        }

        public string Pop()
        {
            if (topo == null)
            {
                throw new InvalidOperationException("Pilha vazia");
            }
            string peca = topo.Peca;
            topo = topo.Proximo;
            return peca;
        }

        public string Peek()
        {
            if (topo == null)
            {
                throw new InvalidOperationException("Pilha vazia");
            }
            return topo.Peca;
        }

        public bool Empty()
        {
            return topo == null;
        }

        public void Print()
        {
            NoPilha temp = topo;
            while (temp != null)
            {
                Console.WriteLine(temp.Peca);
                temp = temp.Proximo;
            }
        }

        public bool Find(string _peca)
        {
            NoPilha temp = topo;
            while (temp != null)
            {
                if (temp.Peca == _peca)
                {
                    return true;
                }
                temp = temp.Proximo;
            }
            return false;
        }

        public void PopValue(string _peca)
        {
            Pilha aux = new Pilha();
            NoPilha temp = topo;
            if(Find(_peca))
            {
               while(temp != null)
               {
                    if(temp.Peca == _peca)
                    {
                        this.Pop();
                        while(aux != null)
                        {
                            this.Push(aux.Pop());
                        }
                        break;
                    }
                    else
                    {
                        aux.Push(this.Pop());
                        temp = temp.Proximo;
                    }
               }
            }
            else
            {
                throw new InvalidOperationException("Peça não encontrada");
            }
        }
    }
}
